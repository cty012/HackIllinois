# How to run
need MySQL and node.js installed. After setting up the MySQL database, run `npm install` in this directory. Then run `npm start` and go to localhost on a browser.
